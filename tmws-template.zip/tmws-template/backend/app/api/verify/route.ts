// app/api/verify/route.ts
// GET /api/verify?code=...  Public. Powers the QR on the agreement letter and the "Check a record" box.
// Returns the minimum needed to confirm a person is real and in good standing.
// Never returns email, staff ID, salary, attendance or the scan.
import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/server';
import { corsHeaders, preflight } from '@/lib/cors';

export const OPTIONS = preflight;

export async function GET(req: Request) {
  const headers = { ...corsHeaders(req, 'GET, OPTIONS'), 'Cache-Control': 'no-store' };
  const code = new URL(req.url).searchParams.get('code')?.trim() ?? '';
  // TODO: add a rate limit (per IP, e.g. 30/min) so this cannot be used to enumerate records.
  if (!/^[A-Za-z0-9-]{8,40}$/.test(code)) return NextResponse.json({ valid: false }, { headers });

  const { data } = await supabaseAdmin
    .from('staff_records')
    .select('full_name, profession, branch, status, created_at')
    .or(`record_code.eq.${code.toLowerCase()},letter_code.eq.${code.toLowerCase()}`)
    .eq('status', 'verified')
    .maybeSingle();

  if (!data) return NextResponse.json({ valid: false }, { headers });
  return NextResponse.json(
    { valid: true, name: data.full_name, profession: data.profession, branch: data.branch, status: 'verified', since: data.created_at.slice(0, 10) },
    { headers },
  );
}
