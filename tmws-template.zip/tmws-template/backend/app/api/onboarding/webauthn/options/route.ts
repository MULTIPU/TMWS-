// app/api/onboarding/webauthn/options/route.ts  (requires @simplewebauthn/server v11+)
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { generateRegistrationOptions } from '@simplewebauthn/server';
import { requireUser, RP_ID, RP_NAME } from '@/lib/server';

export async function POST(req: Request) {
  const user = await requireUser(req);

  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID: RP_ID,
    userName: user.email,
    userDisplayName: user.full_name,
    userID: new TextEncoder().encode(user.id),
    attestationType: 'none',
    authenticatorSelection: {
      authenticatorAttachment: 'platform', // device fingerprint / face unlock
      userVerification: 'required', // forces the biometric or PIN prompt
      residentKey: 'preferred',
    },
  });

  // Short-lived, httpOnly cookie holds the challenge until /verify.
  (await cookies()).set('wms_reg_challenge', options.challenge, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/api/onboarding',
    maxAge: 300,
  });

  return NextResponse.json(options);
}
