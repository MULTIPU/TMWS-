'use client';
// app/onboarding/page.tsx  (requires @simplewebauthn/browser v11+)
import { useEffect, useRef, useState } from 'react';
import { startRegistration } from '@simplewebauthn/browser';
import { Check, Fingerprint, Loader2, ShieldCheck } from 'lucide-react';
import { CLAUSES, ORIENTATION_MODULES } from '@/lib/contract';

type Step = 'orientation' | 'contract' | 'sign' | 'done';
type Receipt = { hash: string; notaryId: string; signedAt: string };

const STEPS: { id: Step; label: string }[] = [
  { id: 'orientation', label: 'Orientation' },
  { id: 'contract', label: 'Read the agreement' },
  { id: 'sign', label: 'Sign with your device' },
  { id: 'done', label: 'Receipt' },
];

export default function OnboardingPage() {
  const [step, setStep] = useState<Step>('orientation');
  const [modulesDone, setModulesDone] = useState<string[]>([]);
  const [accepted, setAccepted] = useState<string[]>([]);
  const [reachedEnd, setReachedEnd] = useState(false);
  const [fullName, setFullName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  const toggle = (list: string[], set: (v: string[]) => void, id: string) =>
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);

  // Require the reader to reach the end of the agreement before the clause boxes unlock.
  useEffect(() => {
    if (step !== 'contract' || !endRef.current) return;
    const io = new IntersectionObserver(([e]) => e.isIntersecting && setReachedEnd(true));
    io.observe(endRef.current);
    return () => io.disconnect();
  }, [step]);

  const allModules = modulesDone.length === ORIENTATION_MODULES.length;
  const allClauses = accepted.length === CLAUSES.length;

  async function sign() {
    setBusy(true);
    setError(null);
    try {
      const optRes = await fetch('/api/onboarding/webauthn/options', { method: 'POST' });
      if (!optRes.ok) throw new Error('Could not start signing. Sign in again and retry.');
      const optionsJSON = await optRes.json();

      const response = await startRegistration({ optionsJSON }); // device biometric prompt

      const verRes = await fetch('/api/onboarding/webauthn/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ response, fullName, acceptedClauseIds: accepted }),
      });
      const data = await verRes.json();
      if (!verRes.ok) throw new Error(data.error ?? 'Signing failed.');
      setReceipt(data);
      setStep('done');
    } catch (e: any) {
      setError(
        e?.name === 'NotAllowedError'
          ? 'The device prompt was cancelled. Select Sign agreement to try again.'
          : e?.message ?? 'Signing failed.',
      );
    } finally {
      setBusy(false);
    }
  }

  const current = STEPS.findIndex((s) => s.id === step);

  return (
    <main className="min-h-screen bg-[#F5F7F8] text-[#17212B]">
      <div className="mx-auto max-w-2xl px-4 py-8 sm:py-12">
        <h1 className="text-2xl font-semibold tracking-tight">Join The Working System</h1>
        <p className="mt-1 text-sm text-[#5B6873]">
          Finish orientation, read your agreement, then sign it with your device.
        </p>

        {/* Progress */}
        <ol className="mt-6 flex gap-2" aria-label="Progress">
          {STEPS.map((s, i) => (
            <li key={s.id} className="flex-1">
              <div className={`h-1 rounded-full ${i <= current ? 'bg-[#0E7C7B]' : 'bg-[#D5DCE1]'}`} />
              <span className={`mt-1 block text-xs ${i === current ? 'font-medium' : 'text-[#5B6873]'}`}>
                {s.label}
              </span>
            </li>
          ))}
        </ol>

        {/* 1. Orientation */}
        {step === 'orientation' && (
          <section className="mt-8">
            <h2 className="text-lg font-medium">Confirm you completed orientation</h2>
            <p className="mt-1 text-sm text-[#5B6873]">Tick each session you attended across the two days.</p>
            <ul className="mt-4 divide-y divide-[#D5DCE1] rounded-lg border border-[#D5DCE1] bg-white">
              {ORIENTATION_MODULES.map((m) => (
                <li key={m.id}>
                  <label className="flex cursor-pointer items-start gap-3 p-4">
                    <input
                      type="checkbox"
                      className="mt-1 h-4 w-4 accent-[#0E7C7B]"
                      checked={modulesDone.includes(m.id)}
                      onChange={() => toggle(modulesDone, setModulesDone, m.id)}
                    />
                    <span className="flex-1">
                      <span className="block text-sm font-medium">{m.title}</span>
                      <span className="text-xs text-[#5B6873]">Day {m.day}, {m.minutes} minutes</span>
                    </span>
                  </label>
                </li>
              ))}
            </ul>
            <button
              disabled={!allModules}
              onClick={() => setStep('contract')}
              className="mt-6 w-full rounded-lg bg-[#0E7C7B] px-4 py-3 text-sm font-medium text-white disabled:bg-[#B9C4CB] sm:w-auto"
            >
              Continue to agreement
            </button>
          </section>
        )}

        {/* 2. Contract */}
        {step === 'contract' && (
          <section className="mt-8">
            <h2 className="text-lg font-medium">Your employment agreement</h2>
            <p className="mt-1 text-sm text-[#5B6873]">
              Scroll to the end, then accept each clause. You can ask HR about any clause before signing.
            </p>
            <div className="mt-4 max-h-[22rem] overflow-y-auto rounded-lg border border-[#D5DCE1] bg-white p-5 font-serif text-[15px] leading-7">
              {CLAUSES.map((c, i) => (
                <div key={c.id} className="mb-5">
                  <h3 className="font-semibold">Clause {i + 1}. {c.title}</h3>
                  <p>{c.body}</p>
                </div>
              ))}
              <div ref={endRef} className="h-px" />
            </div>

            <fieldset disabled={!reachedEnd} className="mt-4 space-y-2 disabled:opacity-50">
              <legend className="sr-only">Accept clauses</legend>
              {CLAUSES.map((c, i) => (
                <label key={c.id} className="flex cursor-pointer items-start gap-3 rounded-lg border border-[#D5DCE1] bg-white p-3">
                  <input
                    type="checkbox"
                    className="mt-1 h-4 w-4 accent-[#0E7C7B]"
                    checked={accepted.includes(c.id)}
                    onChange={() => toggle(accepted, setAccepted, c.id)}
                  />
                  <span className="text-sm">I have read and accept Clause {i + 1}: {c.title}</span>
                </label>
              ))}
            </fieldset>
            {!reachedEnd && <p className="mt-2 text-xs text-[#8A5A00]">Scroll to the end of the agreement to unlock these boxes.</p>}

            <button
              disabled={!allClauses}
              onClick={() => setStep('sign')}
              className="mt-6 w-full rounded-lg bg-[#0E7C7B] px-4 py-3 text-sm font-medium text-white disabled:bg-[#B9C4CB] sm:w-auto"
            >
              Continue to signing
            </button>
          </section>
        )}

        {/* 3. Sign */}
        {step === 'sign' && (
          <section className="mt-8">
            <h2 className="text-lg font-medium">Sign with your device</h2>
            <p className="mt-1 text-sm text-[#5B6873]">
              Type your full name exactly as it appears on your account. Your phone or laptop will then ask for your
              fingerprint, face or PIN.
            </p>
            <label className="mt-4 block text-sm font-medium" htmlFor="fullName">Full name</label>
            <input
              id="fullName"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              autoComplete="name"
              className="mt-1 w-full rounded-lg border border-[#B9C4CB] bg-white px-3 py-3 text-base focus:outline-2 focus:outline-[#0E7C7B]"
            />
            {error && (
              <p role="alert" className="mt-3 rounded-lg border border-[#E3B7B7] bg-[#FBEFEF] p-3 text-sm text-[#8A1F1F]">
                {error}
              </p>
            )}
            <button
              disabled={busy || fullName.trim().length < 3}
              onClick={sign}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-[#17212B] px-4 py-3 text-sm font-medium text-white disabled:bg-[#B9C4CB] sm:w-auto"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Fingerprint className="h-4 w-4" />}
              {busy ? 'Waiting for your device' : 'Sign agreement'}
            </button>
          </section>
        )}

        {/* 4. Receipt */}
        {step === 'done' && receipt && (
          <section className="mt-8 rounded-lg border border-[#D5DCE1] bg-white p-5">
            <div className="flex items-center gap-2 text-[#0E7C7B]">
              <ShieldCheck className="h-5 w-5" />
              <h2 className="text-lg font-medium text-[#17212B]">Agreement signed</h2>
            </div>
            <dl className="mt-4 space-y-3 text-sm">
              <div>
                <dt className="text-[#5B6873]">Signed at</dt>
                <dd>{new Date(receipt.signedAt).toLocaleString()}</dd>
              </div>
              <div>
                <dt className="text-[#5B6873]">e-Notary verification ID</dt>
                <dd className="break-all font-mono text-xs">{receipt.notaryId}</dd>
              </div>
              <div>
                <dt className="text-[#5B6873]">Agreement hash (SHA-256)</dt>
                <dd className="break-all font-mono text-xs">{receipt.hash}</dd>
              </div>
            </dl>
            {receipt.notaryId.startsWith('PENDING-') && (
              <p className="mt-4 text-xs text-[#8A5A00]">Notary anchoring is pending. HR will confirm once it completes.</p>
            )}
            <p className="mt-4 flex items-center gap-2 text-sm">
              <Check className="h-4 w-4 text-[#0E7C7B]" /> Next: your selection interview results and category assignment.
            </p>
          </section>
        )}
      </div>
    </main>
  );
}
