-- TMWS staff verification schema (Supabase / Postgres).
-- Run in the Supabase SQL editor. All writes go through the Next.js API using the service role;
-- browsers can only read their own rows.

create type staff_status as enum ('registered','pending_review','verified','rejected','suspended');

create table if not exists staff_records (
  id                 uuid primary key default gen_random_uuid(),
  user_id            uuid not null unique references auth.users(id) on delete cascade,
  staff_code         text not null unique,                 -- TM123456, shown on the letter
  full_name          text not null,
  email              text not null,
  org_email          text,
  org_email_verified boolean not null default false,       -- set only after the one-time code step
  profession         text not null,
  branch             text not null,
  category           text,                                 -- Academics, Works and Tech, Admin and HR, Security and Safety, Welfare and Support
  delegation_level   int check (delegation_level between 1 and 10),
  agreement_version  text,
  agreement_hash     text,                                 -- what the person signed (client copy, for reference)
  biometric_contract_hash text,                            -- authoritative hash from the WebAuthn verify route
  e_notary_verification_id text,
  record_code        text unique,                          -- server code: first 16 hex of biometric_contract_hash
  letter_code        text,                                 -- code printed in the letter QR by the browser
  credential_id      text,
  scan_path          text,                                 -- private storage: agreement-scans/<user_id>/stamped-letter.jpg
  scan_at            timestamptz,
  status             staff_status not null default 'registered',
  reviewed_by        uuid references auth.users(id),
  reviewed_at        timestamptz,
  claimed            jsonb,                                -- what the browser said about status/rank (never trusted)
  record_hash        text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
create index if not exists staff_letter_code_idx on staff_records (letter_code);

-- Server-owned attendance: the one-record-per-session rule is enforced by the unique key.
create table if not exists attendance (
  id         uuid primary key default gen_random_uuid(),
  staff_id   uuid not null references staff_records(id) on delete cascade,
  work_date  date not null,
  session    text not null check (session in ('morning','afternoon')),
  branch     text not null,
  status     text not null check (status in ('approved','pending','rejected')),
  weight     int  not null check (weight in (1,2)),        -- Mon/Fri 2, Tue-Thu 1
  signed_in  timestamptz not null default now(),
  signed_out timestamptz,
  lat double precision, lng double precision, accuracy_m double precision,
  attempts   int not null default 1,
  unique (staff_id, work_date, session)
);

create table if not exists audit_log (
  id bigint generated always as identity primary key,
  at timestamptz not null default now(),
  actor uuid, action text not null, subject uuid, detail jsonb
);

-- Anonymous reports: no user id, no IP, readable only by restricted roles.
create table if not exists speak_up (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  category text not null check (category in ('Supervisor bias','Safety hazard','Something else')),
  body text not null check (char_length(body) between 10 and 4000)
);

alter table staff_records enable row level security;
alter table attendance    enable row level security;
alter table audit_log     enable row level security;
alter table speak_up      enable row level security;

create policy "own record"     on staff_records for select using (auth.uid() = user_id);
create policy "own attendance" on attendance    for select using (staff_id in (select id from staff_records where user_id = auth.uid()));
-- No insert/update/delete policies: only the service role (the API) can write.
-- audit_log and speak_up have no policies: only the service role and a dedicated reviewer role can read.

-- Private bucket for stamped-letter photos (create in Storage UI, "public" OFF):
--   insert into storage.buckets (id, name, public) values ('agreement-scans','agreement-scans', false);
