// TMWS template settings. Edit this file for each site. Everything is optional.
window.TMWS_CONFIG = {
  brand: 'TMWS',
  demoMode: true,                      // true = demo sign-in and local storage only
  adminEmail: 'mdmasterdan@gmail.com', // second approver for profession changes
  siteUrl: 'https://multipu.github.io/TMWS-/', // the published TMWS site (used in links and QR targets)
  hubUrl: '',                          // your MultiPU Hub address; shows a "MultiPU Hub" link when set
  recordEndpoint: '',                  // e.g. 'https://api.example.com/api/staff/record' (POST staff record). Empty = demo, device only
  verifyEndpoint: '',                  // e.g. 'https://api.example.com/api/verify' (GET ?code=). Empty = demo, device only
  // getToken: async () => (await supabase.auth.getSession()).data.session?.access_token, // production: sent as Bearer token
  branches: [                          // add lat/lng for GPS checks, or save them in Settings
    { n: 'Main branch' }, { n: 'Branch 2' }, { n: 'Branch 3' }
  ],
  morning: [7, 12],                    // 07:00 to 11:59
  afternoon: [12, 18],                 // 12:00 to 18:00
  geofenceMeters: 150,
  pendingLimit: 3,                     // pending sign-ins allowed per month
  recheckMinutes: 5
};
