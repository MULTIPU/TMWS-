// TMWS template settings. Edit this file for each site. Everything is optional.
window.TMWS_CONFIG = {
  brand: 'TMWS',
  demoMode: true,                      // true = demo sign-in and local storage only
  adminEmail: 'mdmasterdan@gmail.com', // second approver for profession changes
  branches: [                          // add lat/lng for GPS checks, or save them in Settings
    { n: 'Main branch' }, { n: 'Branch 2' }, { n: 'Branch 3' }
  ],
  morning: [7, 12],                    // 07:00 to 11:59
  afternoon: [12, 18],                 // 12:00 to 18:00
  geofenceMeters: 150,
  pendingLimit: 3,                     // pending sign-ins allowed per month
  recheckMinutes: 5
};
